xmodmap ~/.xmodmaprc 
